// ai-app-frontend/src/environments/environment.prod.ts

export const environment = {
  production: true,
  apiUrl: '/api'  // Nginx va face proxy către backend
};